package main

import "github.com/PentestPad/subzy/cmd"

func main() {
	cmd.Execute()
}
